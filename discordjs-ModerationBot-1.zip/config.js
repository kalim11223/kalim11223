exports.Prefix = `!`;
exports.Token = `ODI3NjIzNzE5NDgzNjA0OTk0.YGdupw.BTtGQ48Mlm-KMQ70RA3eEbGAHrI`;
exports.Color = `RANDOM`;